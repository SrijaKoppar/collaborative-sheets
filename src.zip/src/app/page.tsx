"use client"

import { collection, getDocs, addDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import Link from "next/link"
import { useEffect, useState } from "react"

export default function Page() {

  const [docs, setDocs] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  async function loadDocs() {

    const snap = await getDocs(collection(db, "documents"))

    const list = snap.docs.map((doc) => ({
      id: doc.id,
      ...doc.data()
    }))

    setDocs(list)
    setLoading(false)
  }

  useEffect(() => {
    loadDocs()
  }, [])

  async function createDocument() {

    const ref = await addDoc(collection(db, "documents"), {
      title: "Untitled Sheet",
      author: "Guest",
      updatedAt: Date.now(),
      cells: {}
    })

    window.location.href = `/doc/${ref.id}`
  }

  return (

    <div className="max-w-6xl mx-auto py-12 px-6">

      {/* Header */}
      <div className="flex items-center justify-between mb-8">

        <div>
          <h1 className="text-3xl font-semibold">
            Your Documents
          </h1>
          <p className="text-gray-500 text-sm mt-1">
            Collaborative spreadsheets
          </p>
        </div>

        <button
          onClick={createDocument}
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md shadow-sm transition"
        >
          + New Spreadsheet
        </button>

      </div>

      {/* Loading */}
      {loading && (
        <div className="text-gray-400">
          Loading documents...
        </div>
      )}

      {/* Empty State */}
      {!loading && docs.length === 0 && (
        <div className="text-gray-400 text-sm">
          No documents yet. Create your first spreadsheet.
        </div>
      )}

      {/* Documents Grid */}
      <div className="grid md:grid-cols-3 gap-5">

        {docs.map((d: any) => (

          <Link
            key={d.id}
            href={`/doc/${d.id}`}
            className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm hover:shadow-md hover:border-gray-300 transition"
          >

            <div className="flex items-center justify-between mb-2">

              <h2 className="font-medium text-lg truncate">
                {d.title}
              </h2>

              <span className="text-xs text-gray-400">
                Sheet
              </span>

            </div>

            <p className="text-sm text-gray-500">
              Created by {d.author}
            </p>

            <p className="text-xs text-gray-400 mt-2">
              Last modified recently
            </p>

          </Link>

        ))}

      </div>

    </div>

  )
}