"use client"

import { loginWithGoogle } from "@/lib/auth"

export default function LoginButton(){

  async function handleLogin(){
    await loginWithGoogle()
  }

  return(

    <button
      onClick={handleLogin}
      className="bg-blue-600 text-white px-4 py-2 rounded"
    >
      Sign in with Google
    </button>

  )

}