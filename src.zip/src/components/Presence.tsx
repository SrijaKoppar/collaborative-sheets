export default function Presence({users}:any){

  return(

    <div className="flex items-center gap-2 mb-4">

      <span className="text-sm text-gray-500">
        Active users
      </span>

      {users.map((u:any,i:number)=>(

        <div
          key={i}
          className="w-7 h-7 rounded-full flex items-center justify-center text-xs text-white font-medium"
          style={{background:u.color}}
        >
          {u.name[0]}
        </div>

      ))}

    </div>

  )
}