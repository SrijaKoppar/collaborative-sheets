export default function Toolbar(){

  return(

    <div className="flex items-center gap-2 border rounded-lg bg-white shadow-sm p-2 mb-4">

      <button className="px-3 py-1 hover:bg-gray-100 rounded">
        Bold
      </button>

      <button className="px-3 py-1 hover:bg-gray-100 rounded">
        Italic
      </button>

      <button className="px-3 py-1 hover:bg-gray-100 rounded">
        Color
      </button>

    </div>

  )
}