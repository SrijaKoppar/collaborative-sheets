"use client"

import { useState, useRef, useEffect } from "react"
import Presence from "./Presence"
import WriteStateIndicator from "./WriteStateIndicator"
import ExportMenu from "./ExportMenu"
import { CellData } from "@/types/spreadsheet"

interface DocumentHeaderProps {
  docId: string
  title: string
  onTitleChange?: (title: string) => void
  users?: any[]
  isSaving?: boolean
  lastSaved?: Date
  username?: string
  onUsernameChange?: (username: string) => void
  cells?: Record<string, CellData>
}

export default function DocumentHeader({
  docId,
  title,
  onTitleChange,
  users = [],
  isSaving = false,
  lastSaved,
  username = "Guest User",
  onUsernameChange,
  cells = {}
}: DocumentHeaderProps) {
  
  const [isEditing, setIsEditing] = useState(false)
  const [editTitle, setEditTitle] = useState(title)
  const [isEditingUsername, setIsEditingUsername] = useState(false)
  const [editUsername, setEditUsername] = useState(username)
  const inputRef = useRef<HTMLInputElement>(null)
  const usernameInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus()
      inputRef.current.select()
    }
  }, [isEditing])

  useEffect(() => {
    if (isEditingUsername && usernameInputRef.current) {
      usernameInputRef.current.focus()
      usernameInputRef.current.select()
    }
  }, [isEditingUsername])

  const handleSave = () => {
    if (editTitle.trim() !== title && editTitle.trim()) {
      onTitleChange?.(editTitle.trim())
    } else {
      setEditTitle(title)
    }
    setIsEditing(false)
  }

  const handleSaveUsername = () => {
    if (editUsername.trim() && editUsername.trim() !== username) {
      onUsernameChange?.(editUsername.trim())
      sessionStorage.setItem('sheet-username', editUsername.trim())
    } else {
      setEditUsername(username)
    }
    setIsEditingUsername(false)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSave()
    } else if (e.key === 'Escape') {
      setEditTitle(title)
      setIsEditing(false)
    }
  }

  const handleUsernameKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSaveUsername()
    } else if (e.key === 'Escape') {
      setEditUsername(username)
      setIsEditingUsername(false)
    }
  }

  const getRelativeTime = (date: Date) => {
    const now = new Date()
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000)
    
    if (seconds < 60) return 'just now'
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}m ago`
    const hours = Math.floor(minutes / 60)
    if (hours < 24) return `${hours}h ago`
    return date.toLocaleDateString()
  }

  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          {/* Title Section */}
          <div className="flex-1">
            {isEditing ? (
              <input
                ref={inputRef}
                type="text"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                onBlur={handleSave}
                onKeyDown={handleKeyDown}
                className="text-2xl font-bold bg-blue-50 border-2 border-blue-500 rounded px-3 py-1 w-full max-w-md outline-none text-slate-900"
              />
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="text-2xl font-bold text-slate-900 hover:text-blue-600 transition-colors group flex items-center gap-2"
              >
                {title}
                <svg className="w-5 h-5 text-slate-400 group-hover:text-blue-600 transition-colors opacity-0 group-hover:opacity-100" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z" />
                </svg>
              </button>
            )}
          </div>

          {/* Status Section */}
          <div className="flex items-center gap-6">
            {/* Write State Indicator */}
            <WriteStateIndicator isWriting={isSaving} lastSaved={lastSaved} />

            {/* Export Menu */}
            <ExportMenu cells={cells} title={title} />

            {/* Presence Indicators */}
            {users && users.length > 0 && (
              <Presence users={users} />
            )}
          </div>
        </div>

        {/* Info Bar */}
        <div className="flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-4">
            <span>Editing as:</span>
            {isEditingUsername ? (
              <input
                ref={usernameInputRef}
                type="text"
                value={editUsername}
                onChange={(e) => setEditUsername(e.target.value)}
                onBlur={handleSaveUsername}
                onKeyDown={handleUsernameKeyDown}
                className="px-2 py-1 rounded border border-slate-300 text-slate-700 text-xs font-medium focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            ) : (
              <button
                onClick={() => setIsEditingUsername(true)}
                className="px-2 py-1 rounded text-slate-700 font-medium hover:bg-slate-100 transition-colors text-xs"
              >
                {username}
              </button>
            )}
          </div>
          <div className="flex gap-4">
            <span>Share your spreadsheet to collaborate with others</span>
          </div>
        </div>
      </div>
    </header>
  )
}
