"use client"

import { useState, useEffect } from "react"

interface Props {
  cellId: string
  value: string
  updateCell: (id: string, value: string) => void
}

export default function Cell({ cellId, value, updateCell }: Props) {

  const [localValue, setLocalValue] = useState(value)
  const [editing, setEditing] = useState(false)

  useEffect(() => {
    if (!editing) {
      setLocalValue(value)
    }
  }, [value, editing])

  function handleBlur() {
    setEditing(false)
    updateCell(cellId, localValue)
  }

  return (
    <td className="border border-gray-200 w-28 h-9 hover:bg-blue-50 transition">

      <input
        value={localValue}
        onChange={(e) => setLocalValue(e.target.value)}
        onFocus={() => setEditing(true)}
        onBlur={handleBlur}
        className="
          w-full h-full
          px-2
          text-sm
          bg-transparent
          outline-none
          focus:bg-white
          focus:ring-2
          focus:ring-blue-500
        "
      />

    </td>
  )
}